# Evolución hacia varios grupos

Versión 0.1 · Propuesta de arranque · 6 de noviembre de 2026.

El piloto sirve a Lestonnac 330. Se preparan claves de organización y pruebas de aislamiento, pero no se construyen en esta fase venta, licencias, facturación, altas autónomas ni administración de una plataforma SaaS. DC01 ratifica ese límite.

## Preparación útil desde el inicio

OrganizationId en datos contextualizados, relaciones consistentes y almacenamiento separado por ámbito. Los trabajos transportan ese ámbito y vuelven a autorizar según la operación. Configuración, secciones, textos y audiencias no se suponen globales. Las pruebas usan dos organizaciones sintéticas para detectar referencias cruzadas aunque producción empiece con una.

Un administrador del grupo no adquiere acceso a otro. La futura función de soporte global necesitará una política propia: alcance, justificación, duración, auditoría y acceso a documentos sensibles. No se hereda del rol Administrador del piloto.

## Investigación posterior al piloto

Contrastar con tres a cinco grupos reales necesidades comunes: secciones, formularios, marca, responsables legales, dominio, tamaños y operación. Definir qué es configurable y qué pertenece a la versión común. Decidir quién contrata el servicio y quién trata datos en cada escenario.

Comparar instalación por grupo, base compartida con aislamiento o bases separadas según riesgo, coste, recuperación por grupo y soporte. Ninguna de estas opciones queda aceptada por usar OrganizationId. Migración, soporte y restauración selectiva necesitan pruebas adicionales antes de alojar datos reales de otro grupo.

## Condiciones de un nuevo proyecto de producto

Requisitos y aceptación propios para alta/baja de grupos, aislamiento integral, configuración, dominios, operaciones de soporte, exportación y recuperación por organización, cuotas, cambios de plan si existen, contratos y distribución de responsabilidades. Evaluar también versionado y despliegue sin romper personalizaciones.

Los cimientos multitenant del ERP sirven de referencia de temas a investigar; su host, tenants, empresas, licencias y componentes comerciales no se trasladan como requisitos scout. La [correspondencia documental](../referencias/correspondencia-gts-erp.md) explica esa adaptación.

## Ideas sin compromiso

Censo permanente, rondas, recordatorios avanzados, firma validada, pagos electrónicos y PWA/acceso sin conexión requieren un caso y criterios nuevos. El acceso sin conexión a PDFs privados implicaría riesgos y retirada de caché que no se resuelven con un simple manifiesto PWA. La primera aplicación continúa siendo web adaptable con documentos protegidos.

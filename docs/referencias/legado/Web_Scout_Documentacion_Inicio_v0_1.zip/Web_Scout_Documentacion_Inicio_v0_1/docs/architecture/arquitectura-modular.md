# Arquitectura modular de la web scout

Versión 0.1 · Propuesta de arranque · 6 de noviembre de 2026.

La propuesta es un monolito modular .NET 10 LTS con ASP.NET Core y EF Core. El piloto usa una base relacional, almacenamiento privado separado y una cola duradera de trabajos. La interfaz inicial será Razor Pages o MVC con JavaScript progresivo para las operaciones que lo necesitan.

## Estructura prevista

```text
L330.slnx
src/
  L330.Domain/
  L330.Application/
  L330.Infrastructure/
  L330.Web/
tools/
  L330.Migration/
tests/
  L330.DomainTests/
  L330.ArchitectureTests/
  L330.IntegrationTests/
  L330.WebTests/
docs/
```

`L330.Worker` se incorporará como host separado solo si la operación lo justifica. Los trabajos pueden empezar como servicio alojado en Web sobre la misma cola persistente. No se requiere un proyecto SharedKernel o Contracts separado para iniciar; las abstracciones compartidas y los contratos de módulo vivirán en Application hasta que exista una necesidad probada de extraerlos.

## Dependencias

```mermaid
flowchart TB
  Web[Web] --> App[Application]
  App --> Domain[Domain]
  Infra[Infrastructure] --> App
  Infra --> Domain
  Web --> Infra
  Migration[Herramienta de migración] --> App
  Migration --> Infra
```

Web referencia Infrastructure únicamente para componer dependencias. Las páginas no reciben DbContext ni realizan consultas de negocio por su cuenta. Domain conserva entidades e invariantes sin EF, Identity, HTTP o proveedores de almacenamiento. Application recibe un contexto de organización y usuario ya resuelto y aplica autorización antes de leer o mutar datos.

Los módulos serán carpetas y namespaces dentro de las capas, conforme al [mapa funcional](mapa-funcional-scout.md). Un módulo ofrece interfaces y DTOs explícitos; otro módulo no consume sus entidades rastreadas ni sus DbSets. Las relaciones necesarias de integridad pueden existir en la base única, con OrganizationId coherente, sin obligar a acoplar el dominio mediante navegaciones.

## Persistencia y unidad de trabajo

Se propone un único `L330DbContext` para la base del piloto, incluyendo las tablas de Identity y de negocio, con una sola línea de migraciones. Se validará esta simplificación en ADR09 antes de la primera migración. Configuraciones y consultas se agrupan por módulo. No se copian las bases host y tenant de GTS.ERP.

PostgreSQL y Npgsql compatibles con EF Core 10 son la opción inicial. SQL Server sigue como alternativa DC03 si existe una ventaja operativa verificable. Solo se prueba y soporta un proveedor en el piloto.

La transacción de un caso de uso confirma estado, versión de entidad, vínculos, auditoría y outbox. Los procesos posteriores, como correo, miniatura o limpieza de huérfanos, consumen trabajos idempotentes. No se presume una transacción distribuida con almacenamiento o SMTP. La [política de archivos y datos](modelo-datos.md) y el [contrato de servicios](../integraciones/contratos-api-y-servicios.md) definen la preparación y recuperación.

## Límites del piloto

Una organización operativa, OrganizationId en datos y claves, dos organizaciones sintéticas para probar aislamiento. No se incluyen facturación SaaS, host de licencias, empresas, XAF, Windows ni Legacy Bridge. El proyecto se puede ejecutar en un alojamiento soportado que cumpla requisitos de datos y recuperación; no se presupone que el hosting WordPress actual soporte .NET.

## Comprobaciones de arquitectura

Los tests deberán impedir referencias de Domain a Infrastructure o Web, uso de DbContext desde la interfaz, tipos Domain ajenos en contratos públicos y procesos de archivo sin ámbito. Las restricciones de acceso e integridad se prueban además con base real; pasar tests de namespaces no demuestra privacidad funcional.

Las decisiones detalladas se registran en [ADR](decisiones-arquitectura.md). La [política oficial de soporte .NET](https://dotnet.microsoft.com/en-us/platform/support/policy/dotnet-core) guía la selección de runtime y parches. La partición descrita aquí es la propuesta de este proyecto, no una exigencia de la plataforma.

# Modelo organizativo y de participantes

Versión 0.1 · Propuesta de arranque · 6 de noviembre de 2026.

La organización representa al grupo scout. La sección define una audiencia y un ámbito de responsabilidad dentro de ese grupo. La cuenta autentica a una persona usuaria; el participante identifica a quien corresponde una entrega concreta, sin crear todavía un expediente personal permanente.

| Concepto | Regla del piloto |
| --- | --- |
| Organización | Una activa en la implantación; identidad estable y zona Europe/Madrid inicial |
| Membresía | Vínculo activo de cuenta con organización y perfil funcional |
| Sección | Castores, Manada, Sección Scout, Unidad Esculta y Clan Rover; catálogo configurable |
| Scouters | Audiencia adicional del equipo; no sinónimo del rol de la cuenta |
| Todo el grupo | Audiencia general implícita; no concede gestión global ni acceso a respuestas ajenas |
| Cuenta familiar | Puede actuar en varias secciones y presentar varios participantes |
| Participante | Identidad declarada de una respuesta; su nombre no es clave única |
| Sección responsable | Una o varias asignadas a una respuesta dentro de las permitidas para esa actividad y cuenta |

## Invariantes

- Todas las relaciones de negocio se limitan a la misma organización.
- El contexto de organización procede del servidor y de la membresía activa.
- Sin sección específica, la cuenta ve publicaciones generales y sus propios expedientes; no obtiene alcance global.
- El propietario de una respuesta conserva acceso a su propia documentación según el estado de la cuenta y la política de acceso.
- Un revisor requiere concesión y sección responsable; ver una actividad general no le permite abrir todos sus documentos.
- No se deduce tutela, parentesco o identidad personal por nombre o por compartir una cuenta.

## Decisiones diferidas

El censo de educandos, relaciones de tutela verificadas, rondas y transición automática al perfil adulto exigirán requisitos propios y una migración específica. No se reutiliza el modelo tenant, empresa, centro y departamento del ERP para representar al grupo.

Referencias: RF01 a RF06, RF28, RF31 y RF32 en el [catálogo](../requisitos/catalogo-requisitos.md); [evolución multigrupo](../evolucion/vision-multigrupo.md).
